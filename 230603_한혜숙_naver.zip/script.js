const swiper = new Swiper('.swiper', {
  // Optional parameters
  slidesPerView: 3.2,
  spaceBetween: 15,
  direction: 'vertical',
  loop: true,


});